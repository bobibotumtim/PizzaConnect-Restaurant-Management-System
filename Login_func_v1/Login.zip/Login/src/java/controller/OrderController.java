package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;
import dao.*;
import models.*;

public class OrderController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) {
            action = "list";
        }

        OrderDAO dao = new OrderDAO();

        switch (action) {
            case "new":
                req.getRequestDispatcher("/view/order-form.jsp").forward(req, resp);
                break;

            case "edit":
                int editId = Integer.parseInt(req.getParameter("id"));
                Order editOrder = dao.getOrderById(editId);
                req.setAttribute("order", editOrder);
                req.getRequestDispatcher("/view/order-form.jsp").forward(req, resp);
                break;

            case "delete":
                int delId = Integer.parseInt(req.getParameter("id"));
                dao.deleteOrder(delId);
                resp.sendRedirect("OrderController?action=list");
                break;

            case "detail":
                int id = Integer.parseInt(req.getParameter("id"));
                List<OrderDetail> details = dao.getOrderDetailsByOrderId(id);
                req.setAttribute("details", details);
                req.getRequestDispatcher("/view/order-detail.jsp").forward(req, resp);
                break;

            default:
                List<Order> orders = dao.getAll();
                req.setAttribute("orders", orders);
                req.getRequestDispatcher("/view/order-list.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        // Lấy dữ liệu từ form
        String customerParam = req.getParameter("customerID");
        String employeeParam = req.getParameter("employeeID");
        String tableParam = req.getParameter("tableID");
        String note = req.getParameter("note");

        // Kiểm tra hợp lệ dữ liệu nhập
        int customerID = parseIntSafe(customerParam);
        int employeeID = parseIntSafe(employeeParam);
        int tableID = parseIntSafe(tableParam);

        // Nếu nhập sai (ví dụ chữ, rỗng) → báo lỗi
        if (customerID <= 0 || employeeID <= 0 || tableID <= 0) {
            req.setAttribute("error", "❌ Vui lòng nhập đúng định dạng số cho Customer ID, Employee ID và Table ID.");
            req.getRequestDispatcher("order-form.jsp").forward(req, resp);
            return;
        }

        // Tạo danh sách chi tiết trống (nếu chưa có chi tiết)
        List<OrderDetail> details = new ArrayList<>();

        OrderDAO dao = new OrderDAO();
        try {
            dao.createOrder(customerID, employeeID, tableID, note, details);
            resp.sendRedirect("OrderController?action=list");
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "⚠️ Không thể lưu đơn hàng. Vui lòng thử lại.");
            req.getRequestDispatcher("order-form.jsp").forward(req, resp);
        }
    }

    /**
     * Hàm tiện ích để parse số an toàn
     */
    private int parseIntSafe(String value) {
        try {
            return Integer.parseInt(value);
        } catch (Exception e) {
            return -1; // trả về -1 nếu không phải số
        }
    }

}
